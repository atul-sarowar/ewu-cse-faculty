(() => {
"use strict";
if (!location.pathname.startsWith("/computer-science-engineering/faculty-members")) return;
if (document.documentElement.dataset.ewuCseModernCorrected) return;
document.documentElement.dataset.ewuCseModernCorrected = "1";

const APPROVED = {"Prof. Dr. Shamim H. Ripon": "DSHR", "Prof. Dr. Md. Nawab Yousuf Ali": "NYA", "Prof. Dr. Taskeed Jabid": "TJ", "Dr. Mohammad Rezwanul Huq": "DMRH", "Dr. Anisur Rahman": "MAR", "Dr. Anup Kumar Paul": "DAKP", "Dr. Sarwar Jahan": "SJ", "Dr. Mohammad Salah Uddin": "DSU", "Dr. Md. Sawkat Ali": "ALI", "Dr. Raihan Ul Islam": "DRUI", "Dr. Md. Mostofa Kamal Rasel": "MKR", "Dr. Mohammad Rifat Ahmmad Rashid": "MRAR", "Dr. Mohammad Mahdi Hassan": "MMAHDI", "Dr. Mohammad Manzurul Islam": "DMIM", "Dr. Md. Hasanul Ferdaus": "DAHF", "Dr. Hasan Mahmood Aminul Islam": "DHMAI", "Dr. Md. Atiqur Rahman": "ATIQ", "Dr. Md. Tauhid Bin Iqbal": "DTBI", "Dr. Tania Sultana": "DTS", "Dr. Farhana Huq": "FHUQ", "Dr. Nafis Sadeq": "NAFIS", "Dr. Hosney Jahan": "DHJ", "Dr. Zubaer Ibna Mannan": "DZIM", "Rashedul Amin Tuhin": "RDA", "M. Saddam Hossain Khan": "SHK", "Musharrat Khan": "MKN", "Md. Al-Imran": "IMRAN", "Sadika Islam Sneha": "SDIS", "Md. Khalid Mahbub Khan": "KHALID", "Amit Mandal": "AMITM", "Mahmuda Rawnak Jahan": "MRJ", "Ahmed Abdal Shafi Rasel": "AASR", "Ms. Sadia Nur Amin": "SDNA", "Puja Chakraborty": "PC", "Khairum Islam": "KRI", "Nishat Tasnim": "NISHAT", "Fouzia Risdin": "FZRN", "Md Ashraful Haider Chowdhury": "MAHCY", "Md. Arman Hossain": "ARMAN", "Md Sabbir Hossain": "SABBIR", "Md. Asif Khan Rifat": "RIFAT", "Rabea Khatun": "RABEA", "Shatabdi Roy Moon": "MOON", "Yasin Sazid": "YS", "K. M. Safin Kamal": "KMSK", "Md. Adnan Morshed": "MAMRD", "Asraf Ullah Rahat": "AUR", "Sanzana Karim Lora": "SKL", "Mahmudul Islam Rakib": "MIR", "Antu Chowdhury": "ANTU", "Tahsin Tariq Banna": "TTB", "Ahmed Adnan": "AADNAN", "Proma Chowdhury": "PROMA", "Muhammed Yaseen Morshed Adib": "MYMA", "Nahid Hasan": "NAHID", "Syed Jamiul Alam": "SJA", "Shartaz Sajid Nahid": "SAJID", "Koushik Sarkar": "KOUSHIK", "Dr. Maheen Islam": "MAHEEN", "Dr. Md. Mozammel Huq Azad Khan": "MHAK"};
const NORMALIZED = {"shamim h ripon": "DSHR", "md nawab yousuf ali": "NYA", "taskeed jabid": "TJ", "mohammad rezwanul huq": "DMRH", "anisur rahman": "MAR", "anup kumar paul": "DAKP", "sarwar jahan": "SJ", "mohammad salah uddin": "DSU", "md sawkat ali": "ALI", "raihan ul islam": "DRUI", "md mostofa kamal rasel": "MKR", "mohammad rifat ahmmad rashid": "MRAR", "mohammad mahdi hassan": "MMAHDI", "mohammad manzurul islam": "DMIM", "md hasanul ferdaus": "DAHF", "hasan mahmood aminul islam": "DHMAI", "md atiqur rahman": "ATIQ", "md tauhid bin iqbal": "DTBI", "tania sultana": "DTS", "farhana huq": "FHUQ", "nafis sadeq": "NAFIS", "hosney jahan": "DHJ", "zubaer ibna mannan": "DZIM", "rashedul amin tuhin": "RDA", "m saddam hossain khan": "SHK", "musharrat khan": "MKN", "md al-imran": "IMRAN", "sadika islam sneha": "SDIS", "md khalid mahbub khan": "KHALID", "amit mandal": "AMITM", "mahmuda rawnak jahan": "MRJ", "ahmed abdal shafi rasel": "AASR", "sadia nur amin": "SDNA", "puja chakraborty": "PC", "khairum islam": "KRI", "nishat tasnim": "NISHAT", "fouzia risdin": "FZRN", "md ashraful haider chowdhury": "MAHCY", "md arman hossain": "ARMAN", "md sabbir hossain": "SABBIR", "md asif khan rifat": "RIFAT", "rabea khatun": "RABEA", "shatabdi roy moon": "MOON", "yasin sazid": "YS", "k m safin kamal": "KMSK", "md adnan morshed": "MAMRD", "asraf ullah rahat": "AUR", "sanzana karim lora": "SKL", "mahmudul islam rakib": "MIR", "antu chowdhury": "ANTU", "tahsin tariq banna": "TTB", "ahmed adnan": "AADNAN", "proma chowdhury": "PROMA", "muhammed yaseen morshed adib": "MYMA", "nahid hasan": "NAHID", "syed jamiul alam": "SJA", "shartaz sajid nahid": "SAJID", "koushik sarkar": "KOUSHIK", "maheen islam": "MAHEEN", "md mozammel huq azad khan": "MHAK"};
const state = { query:"", filter:"All", dark:localStorage.getItem("ewu-cse-dark") === "1" };

const clean = s => (s || "").replace(/\s+/g," ").trim();
const el = (tag, cls, text) => {
  const x=document.createElement(tag);
  if(cls) x.className=cls;
  if(text!==undefined) x.textContent=text;
  return x;
};

function norm(s){
  return clean(s).toLowerCase()
    .replace(/[.,'’`]/g,"")
    .split(/\s+/)
    .filter(Boolean)
    .filter(x => !new Set(["prof","professor","dr","doctor","engr","engineer","mr","mrs","ms","miss"]).has(x))
    .join(" ");
}

function initialFor(name){
  const n=norm(name);
  if(NORMALIZED[n]) return NORMALIZED[n];

  // Explicit special case requested for Azad Sir.
  if(/\bazad\b/i.test(name)) return "MHAK";

  // Fallback ONLY for people outside the approved mapping.
  const words=norm(name).split(/\s+/).filter(Boolean);
  return words.slice(0,3).map(w=>w[0]).join("").toUpperCase();
}

function facultyList(){
  const out=[], seen=new Set();
  document.querySelectorAll("h1,h2,h3,h4,h5,h6").forEach(h=>{
    const link=h.querySelector("a[href]");
    if(!link) return;
    const name=clean(link.textContent), href=link.href;
    if(!name || seen.has(href)) return;

    let block=h.parentElement;
    for(let i=0;i<7 && block;i++,block=block.parentElement){
      const t=clean(block.textContent);
      if(/view profile/i.test(t) && /(Professor|Lecturer|Dean|Chairperson)/i.test(t)) break;
    }
    if(!block) return;

    const info=clean(block.textContent).replace(name,"").replace(/view profile/ig,"");
    let rank="Faculty";
    for(const r of ["Associate Professor","Assistant Professor","Senior Lecturer","Professor","Lecturer"]){
      if(new RegExp("\\b"+r.replace(" ","\\s+")+"\\b","i").test(info)){rank=r;break;}
    }
    const extra=[];
    for(const x of ["Dean","Chairperson","Proctor","On Study Leave"]){
      if(new RegExp("\\b"+x.replace(" ","\\s+")+"\\b","i").test(info)) extra.push(x);
    }

    const image=block.querySelector("img")?.src || "";
    out.push({name,href,rank,extra,image,initial:initialFor(name),block});
    seen.add(href);
  });
  return out;
}

function build(){
  const faculty=facultyList();
  if(!faculty.length) return;
  faculty.forEach(f=>f.block.classList.add("ewu-original"));

  const app=el("div","ewu-app");

  const hero=el("section","ewu-hero");
  const copy=el("div");
  copy.append(
    el("div","eyebrow","EAST WEST UNIVERSITY  •  CSE"),
    el("h1","","Faculty Directory"),
    el("p","","Explore the Computer Science & Engineering faculty at EWU.")
  );
  const stat=el("div","stat");
  stat.innerHTML=`<b>${faculty.length}</b><span>faculty members</span>`;
  copy.append(stat);

  const visual=el("div","visual");
  visual.innerHTML='<i></i><i></i><i></i><b>CSE</b><em></em><em></em><em></em>';
  hero.append(copy,visual);

  const controls=el("section","controls");
  const search=el("label","search");
  search.innerHTML="<span>⌕</span>";
  const input=el("input");
  input.placeholder="Search by faculty name or initial (e.g. TJ, NYA, DSHR)…";
  search.append(input);

  const select=el("select");
  ["All","Professor","Associate Professor","Assistant Professor","Senior Lecturer","Lecturer"].forEach(v=>{
    const o=el("option","",v); o.value=v; select.append(o);
  });

  const dark=el("button","theme",state.dark?"☀ Light":"◐ Dark");
  controls.append(search,select,dark);

  const hint=el("div","hint");
  hint.innerHTML="<b>INITIAL SEARCH</b> Approved initials are kept exactly as provided.";

  const grid=el("section","grid");
  const empty=el("div","empty","No faculty members match your search.");

  function render(){
    const q=clean(state.query).toLowerCase();
    grid.innerHTML="";
    let count=0;

    faculty.forEach(f=>{
      const hay=[f.name,f.initial,f.rank,...f.extra].join(" ").toLowerCase();
      if(q && !hay.includes(q)) return;
      if(state.filter!=="All" && f.rank!==state.filter) return;
      count++;

      const card=el("a","card");
      card.href=f.href;

      const photo=el("div","photo");
      if(f.image){
        const img=el("img");
        img.src=f.image; img.alt=f.name; img.loading="lazy";
        img.onerror=()=>{img.remove(); photo.classList.add("initial"); photo.textContent=f.initial;};
        photo.append(img);
      } else {
        photo.classList.add("initial"); photo.textContent=f.initial;
      }

      const body=el("div","body");
      const top=el("div","top");
      top.append(el("span","rank",f.rank),el("span","initial-badge",f.initial));
      body.append(top,el("h2","",f.name));

      if(f.extra.length){
        const ex=el("div","extra");
        f.extra.forEach(x=>ex.append(el("span","",x)));
        body.append(ex);
      }

      const foot=el("div","foot");
      foot.innerHTML="<span>View profile</span><span>↗</span>";
      body.append(foot);
      card.append(photo,body);
      grid.append(card);
    });
    empty.style.display=count?"none":"block";
  }

  input.addEventListener("input",()=>{state.query=input.value;render();});
  select.addEventListener("change",()=>{state.filter=select.value;render();});
  dark.addEventListener("click",()=>{
    state.dark=!state.dark;
    localStorage.setItem("ewu-cse-dark",state.dark?"1":"0");
    document.documentElement.classList.toggle("dark",state.dark);
    dark.textContent=state.dark?"☀ Light":"◐ Dark";
  });

  app.append(hero,controls,hint,grid,empty);
  const title=[...document.querySelectorAll("h1,h2,h3,h4,h5,h6")].find(x=>clean(x.textContent)==="Faculty Members");
  const anchor=title?.closest("section,.container,.content-area") || title?.parentElement;
  (anchor || document.body).prepend(app);

  document.documentElement.classList.toggle("dark",state.dark);
  render();

  // Verification aid: log the two previously wrong examples.
  console.info("[EWU CSE UI] Verified initials:", {
    "Dr. Shamim H Ripon": initialFor("Dr. Shamim H Ripon"),
    "Dr. Md. Nawab Yousuf Ali": initialFor("Dr. Md. Nawab Yousuf Ali"),
    "Dr. Md. Mozammel Huq Azad Khan": initialFor("Dr. Md. Mozammel Huq Azad Khan")
  });
}
setTimeout(build,500);
})();